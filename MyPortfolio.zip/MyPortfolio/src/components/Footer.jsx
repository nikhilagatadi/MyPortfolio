import React from 'react'

export default function Footer() {
  return (
    <footer>
      <p>&copy; 2025 Gatadi Nikhila | Fresher</p>
    </footer>
  )
}
